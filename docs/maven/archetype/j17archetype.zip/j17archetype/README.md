java17-quickstart archetype

Building the archetype:
  mvn install

Usage:
  mvn archetype:generate \
    -DarchetypeGroupId=com.kaczurba \
    -DarchetypeArtifactId=j17-quickstart \
  -DarchetypeVersion=1.1-SNAPSHOT \
  -DgroupId=com.project \
  -DartifactId=first-project

  
